#Write a program which displays first 10 even numbers on the screen

for no in range(2,21,2):
    print(no)