#Write a program which display 5 times Marvellous on screen


for i in range(5):
    print("Marvellous")

