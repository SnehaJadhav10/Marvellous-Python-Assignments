#Write a program which accepts number from user and print that number of "*" on screen

print("Enter Number :")
no = int(input())

print("*"*no)