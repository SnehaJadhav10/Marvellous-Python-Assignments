#Write a program which display 10 to 1 on screen

for no in range(10,0,-1):
    print(no)