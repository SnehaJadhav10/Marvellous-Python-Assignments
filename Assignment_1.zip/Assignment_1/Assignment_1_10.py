#write a program which accept name from user and display length of its name

print("Enter Name :")
name = str(input())

print(len(name))